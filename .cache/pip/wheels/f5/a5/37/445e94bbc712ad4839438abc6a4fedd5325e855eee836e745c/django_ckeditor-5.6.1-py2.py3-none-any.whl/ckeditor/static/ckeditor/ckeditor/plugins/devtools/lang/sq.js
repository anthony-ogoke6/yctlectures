﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","sq",{title:"Të dhënat e elementit",dialogName:"Emri i dritares së dialogut",tabName:"Emri i fletës",elementId:"ID e elementit",elementType:"Lloji i elementit"});