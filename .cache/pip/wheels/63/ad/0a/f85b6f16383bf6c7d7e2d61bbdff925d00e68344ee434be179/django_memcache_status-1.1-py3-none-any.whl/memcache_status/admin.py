from django.contrib import admin

admin.site.index_template = 'memcache_status/index.html'